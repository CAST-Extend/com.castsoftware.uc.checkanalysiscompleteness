from sqlalchemy import inspect
from .central import CentralBase
from . import KnowledgeBase, ConnectionSharing, create_postgres_engine



class Combined:
    """
    The classical combination of a management, local, and central.
    
    Also known as 'triplet'. 
    """
    def __init__(self, server, name):
        
        self.server = server
        self.name = name
        
        self.local = None
        self.central = None
        self.mngt = None
        
    def get_local(self):
        """
        
        """
        if not self.local:
            
            self.local = KnowledgeBase(self.name + '_local', self.server.engine)
        
        return self.local
    
    def get_central(self):
        
        if not self.central:
            
            self.central = CentralBase(self.name + '_central', self.server.engine)
        
        return self.central
    
    def get_managment(self):
        
        if not self.mngt:
            from .managment import ManagmentBase

            self.mngt = ManagmentBase(self.name + '_mngt', self.server.engine)
        
        return self.mngt
    
    def __repr__(self):
        
        return "Combined(%s)" %self.name
        
        

class Server:
    """
    Connection to a server.
    """
    # caching
    servers = {}
    
    def __init__(self, engine=None):
        
        self.engine = engine or create_postgres_engine()
        # connection sharing
        self.connection, self.raw_connection = ConnectionSharing.get_connections(self.engine)
        
        # storage for caching
        self.schemas = {}
        
        # caching
        Server.servers[self.engine] = self
        

    @staticmethod
    def get_server(engine):
        """
        Access to serve by engine
        """
        try:
            return Server.servers[engine]
        except:
            return Server(engine)
        
    def get_schema(self, name):
        """
        Open a schema by name and autodetect its nature.
        """
        
        # cache first
        try:
            return self.schemas[name]
        except:
            pass
        
        all_schemas = self.__get_all_schemas()

        if name in all_schemas:
            
            result = self.engine.execute("select * from %s.SYS_PACKAGE_VERSION" % name)
            
            names = set((line[0] for line in result))
            
            result = None
            
            if 'ADG_CENTRAL' in names:
                result = CentralBase(name, self.engine)
            elif 'PMC_MAIN'  in names:
                from .managment import ManagmentBase
                result = ManagmentBase(name, self.engine)
            elif 'APPW'  in names:
                result = KnowledgeBase(name, self.engine)
            else:
                raise RuntimeError('Schema "%s" is not an eligible CAST schema.' % name)
            
            self.schemas[name] = result
            return result
            
        else:
            
            raise RuntimeError('Schema "%s" does not exist.' % name)
        

    def get_combined_installs(self):
        """
        Get all the triplets of a schema.
        """
        result = []
        
        all_schemas = self.__get_all_schemas()
        for schema in all_schemas:
            
            if schema.endswith('_mngt'):
                
                small_name = schema[:-5]
                
                if small_name + '_local' in all_schemas and small_name + '_central' in all_schemas:
                    
                    combined = Combined(self, small_name)
                    
                    result.append(combined)
        
        return result
        
    def get_combined_install(self, name):
        """
        Get a triplet of a schema.
        """
        for triplet in self.get_combined_installs():
            
            if triplet.name == name:
                return triplet
        
    def get_managment_schemas(self):
        """
        Access to all management schemas in the server.
        
        @todo : support non standard (_mngt) schemas
        """
        result = []
        for schema in self.__get_all_schemas():
            if schema.endswith('_mngt'):
                result.append(self.get_schema(schema))
                
        return result

    def get_local_schemas(self):
        """
        Access to all local schemas in the server.
        
        @todo : support non standard (_local) schemas
        """
        result = []
        for schema in self.__get_all_schemas():
            if schema.endswith('_local'):
                result.append(self.get_schema(schema))
                
        return result
        
            
    def get_managment_schema(self, name):
        """
        Access to a management schema in the server.
        """
        return self.get_schema(name)
    
    def __get_all_schemas(self):
        
        insp = inspect(self.engine)
        return set(insp.get_schema_names())
        
    
        