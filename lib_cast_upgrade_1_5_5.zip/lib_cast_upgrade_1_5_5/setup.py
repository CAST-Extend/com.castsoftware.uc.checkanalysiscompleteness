'''
Created on 26 janv. 2017

@author: MRO
'''
import os
import sys
import logging
from distutils.version import StrictVersion
import xml.etree.ElementTree as eTree
from .internal.p1 import get_message # @UnresolvedImport


class CASTAIP:
    """
    An install for CAIP.
    """
    def __init__(self, path):
        
        # location
        self.__path = path
        
        # deduced...
        self.__version = None
        self.__user_folder = None
        
        self.__read_cwbin()
        self.__read_ini()
        
        # @todo set the default values
        self.__lisa_path = None
        self.__ltsa_path = None
        self.__log_root_path = None
        
        self.__mail_host = None
        self.__mail_port = None
        self.__mail_from = None
        
        self.__mail_user = None
        self.__mail_password = None
        
        self.__read_cms_preferences()

    @staticmethod
    def get_running_caip():
        """
        Get the current CAIP running.
        """
        # the running python.exe indicates the flat location
        python_exe_path = sys.executable
        return CASTAIP(os.path.dirname(os.path.dirname(os.path.dirname(python_exe_path))))

    def get_version(self):
        """
        Version of the flat.
        """
        return self.__version

    def get_user_preferences_path(self):
        """
        Folder used to store preferences
        """
        return self.__user_folder
    
    def get_lisa_path(self):
        """
        Access to configured LISA path
        """
        return self.__lisa_path
    
    def get_mail_server(self):
        """
        Returns an SMTP mail server if it has been configured in CMS.
        
        :returns: smtplib.SMTP
        """
        if self.__mail_host:
            
            import smtplib
            
            result = smtplib.SMTP(self.__mail_host, port=self.__mail_port)
            
            try:
                if self.__mail_user:
                    result.starttls()
                    result.login(self.__mail_user, self.__mail_password)
            except:
                logging.warning('Cannot login to mail server')
                raise
                
            return result
    
    def get_mail_from_address(self):
        """
        Get the address specified as the sender for automatic mail.
        """
        return self.__mail_from
    
    def __read_cms_preferences(self):
        """
        cast-ms.preferences.pmx
        """
        tree = eTree.parse(os.path.join(self.__user_folder, 'cast-ms.preferences.pmx'))
        root = tree.getroot()
        
        lot = next(iter(root))
        
        for preference in lot:
            
            if preference.tag == 'preferences.Preferences':
                
                try:
                    self.__lisa_path = preference.attrib['workingPath']
                except:
                    pass

                try:
                    self.__ltsa_path = preference.attrib['temporaryPath']
                except:
                    pass

                try:
                    self.__log_root_path = preference.attrib['logRootPath']
                except:
                    pass

            else:
                try:
                    self.__mail_host = preference.attrib['host']
                except:
                    pass
        
                try:
                    self.__mail_port = preference.attrib['port']
                except:
                    pass
        
                try:
                    self.__mail_from = preference.attrib['from']
                except:
                    pass
                
                for credential in preference:
                    for credential_preference in credential:
                        
                        try:
                            self.__mail_user = credential_preference.attrib['user']
                        except:
                            pass

                        try:
                            self.__mail_password = get_message(credential_preference.attrib['password'][9:])
                        except:
                            pass
                        
        
    def __read_cwbin(self):
        """
        Extract version from cw.bin
        """
        with open(os.path.join(self.__path, 'cw.bin'), "rb") as cwbin:
            
            versionString = ''
            fileBytes = cwbin.read()
            index = 18
            while True:
                
                current = chr(fileBytes[index]-100)
                if str.isdigit(current) or current == '.':
                    versionString += current;
                else:
                    break
                index += 1
            
            self.__version = StrictVersion(versionString)
            
            
    def __read_ini(self):
        """
        Read CastGlobalSettings.ini to get some variables
        """
        
        values = {'CAST_CURRENT_USER_WORK_PATH':'%APPDATA%\\CAST\\CAST\\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$\\'}
        
        with open(os.path.join(self.__path, 'CastGlobalSettings.ini')) as settings:
            
            for line in settings:
                
                if not line.startswith('CAST_'):
                    continue
                value = line[line.find('=')+1:].strip()

                if line.startswith('CAST_CURRENT_USER_WORK_PATH'):
                    values['CAST_CURRENT_USER_WORK_PATH'] = value           
        
        def expand(text):
        
            text = text.replace('$CAST_MAJOR_VERSION$', str(self.__version.version[0]))
            text = text.replace('$CAST_MINOR_VERSION$', str(self.__version.version[1]))
            text = os.path.expandvars(text)
            return text
            
        self.__user_folder = expand(values['CAST_CURRENT_USER_WORK_PATH'])
    
    def __repr__(self):
        
        return 'CAIP(%s, %s)' % (self.__path, self.__version)
        
        
        