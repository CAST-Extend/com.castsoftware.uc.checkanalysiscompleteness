"""
The part to be maintained

"""
from .. import Application, Bookmark, Database, DatabaseOwner, DatabaseSubset, File
from .. import KnowledgeBase, Object, Project, Reference, ReferenceFinder
from .. import LinkType, LinkQuery, ObjectQuery, EnlightenLink, create_link

# only public API here
patch_classes_names = {'Application':Application, 
                       'Bookmark':Bookmark, 
                       'Database':Database, 
                       'DatabaseOwner':DatabaseOwner, 
                       'DatabaseSubset':DatabaseSubset, 
                       'File':File, 
                       'KnowledgeBase':KnowledgeBase, 
                       'Object':Object, 
                       'Project':Project, 
                       'Reference':Reference, 
                       'ReferenceFinder':ReferenceFinder,
                       'ObjectQuery':ObjectQuery,
                       'LinkQuery':LinkQuery,
                       'EnlightenLink':EnlightenLink,
                       'LinkType':LinkType}


####################
## install part
####################
   

import sys
import cast.application
import inspect
from distutils.version import StrictVersion
import logging


cast_module = sys.modules["cast.application"]


def get_version(cast_module):
    
    if hasattr(cast_module, '__version__'):
        return getattr(cast_module, '__version__')
    else:
        return '1.0.0'

def apply_patch(version):

    if StrictVersion(get_version(cast_module)) < StrictVersion(version):
        """
        lower version so we install ourselves
        """
        setattr(cast_module, '__version__', version)
        clsmembers = inspect.getmembers(cast_module, inspect.isclass)
        
        # logging.info('Upgrading API version to  %s', version)
        
        patched_classes = []
        
        for cast_class in clsmembers:
            
            class_name = cast_class[0]
            class_object = cast_class[1]
            
            if class_name in patch_classes_names:
                
                patched_classes.append(class_name)
                
                patch_class=patch_classes_names[class_name]
                
                for m in inspect.getmembers(patch_class):
                    
                    member_name = m[0]
                    
                    if not member_name.startswith('__') or member_name.startswith('__init') or member_name in ['__repr__', '__eq__', '__hash__']:
                        setattr(class_object, member_name, m[1])
        
        # remaining classes : added to module
        for name, cls in patch_classes_names.items():
            
            if not name in patched_classes:
                
                setattr(cast_module, name, cls)
        
        setattr(cast_module, 'create_link', create_link)
        
        # non generic
        # for > 8.0.0
        try:
            from cast.application.internal import get_current_application
            # reload projects
            get_current_application()._calculate_project_list()
        except:
            pass
            
        