'''
Created on 24 juil. 2014

@author: MRO
'''
from sqlalchemy import Table, Column, Integer, String
import binascii
import logging
from symbol import except_clause
from .reflect import reflect_table


class Saver:
    """
    Saver using AMT saving.
    """
    def __init__(self, application, job_id, name, plugin_id, plugin_version):
        
        self.plugin_id = plugin_id
        self.plugin_version = plugin_version
        self.name = name
        
        self.user_project_id = application.id
        self.kb = application.kb
        self.engine = self.kb.engine
        self.metadata = self.kb.metadata
        self.job_id = job_id
        self.next_id = 1
        self.property_char_offset = 0
        self.property_int_offset = 0

        self.project_type = self.kb.plugin_project_type
        
        self.in_project_link = 1054
        self.parent_link = 1032
        
        self.IN_OBJECTS = reflect_table("IN_OBJECTS", self.metadata, self.engine) 

        self.IN_LINKS = reflect_table("IN_LINKS", self.metadata, self.engine)   
         
        self.IN_CHAR_PROPERTIES = reflect_table("IN_CHAR_PROPERTIES", self.metadata, self.engine)    
        
        self.IN_INT_PROPERTIES = reflect_table("IN_INT_PROPERTIES", self.metadata, self.engine)     
        
        self.IN_POSITIONS = reflect_table("IN_POSITIONS", self.metadata, self.engine) 

        self.cursor = self.kb.create_cursor()
        self.raw_connection = self.kb.raw_connection

        # saving cache : fill this and fill in tables latter
        self.in_objects = []
        self.in_links = []
        self.in_int_properties = []
        self.in_char_properties = []
        self.in_positions = []
        
        self._create_project(self.name)
        
        # projects on wich this one depend
        self.dependent_projects = set()
        
        


    def add_link(self, link_type, caller, callee, bookmark=None):
        """
        Create a link between 2 objects.
        
        @param link_type: either an integer, a string or a Type
        @param caller: either an integer or an Object
        @param callee: either an integer or an Object
        """
        link_id = self.next_id
        self.next_id += 1

        AMT_id_type = 'E'
        KB_id_type = 'I'

        link_type_id = None
        if type(link_type) is int:
            link_type_id = link_type
        elif type(link_type) is str:
            link_type_id = self.kb.metamodel.get_category(name=link_type).id
        else:
            link_type_id = link_type.id
        
        self.in_links.append([self.job_id,
                              link_id,
                              caller if type(caller) is int else caller.id,
                              callee if type(callee) is int else callee.id,
                              -1 if link_type_id == self.in_project_link else self.project_id, 
                              AMT_id_type if type(caller) is int else KB_id_type,
                              AMT_id_type if type(callee) is int else KB_id_type,
                              AMT_id_type,
                              link_type_id
                              ])
        
        
        if bookmark:
            self.add_link_bookmark(link_id, bookmark)
        
        return link_id

    def add_link_bookmark(self, link, bookmark):
        """
        Save a bookmark on a link.
        """
        
        self.in_positions.append([self.job_id,
                                  link,
                                  bookmark.file.id,
                                  'I',
                                  0,  # sequence number are computed in base for links
                                  2,  # line/col position type
                                  bookmark.begin_line,
                                  bookmark.begin_column,
                                  bookmark.end_line,
                                  bookmark.end_column,
                                  -1
                                  ])
        
    def add_property(self, object, property, value):
        
        if property.get_type() == 'string' and type(value) is str:

            logging.debug('save_property %s %s %s', str(object), str(property), str(value))

            
            values = [value]
    
            if len(value) > 255:
                values = [value[i:i+255] for i in range(0, len(value), 255)]
            
            char_block = 0
            
            for val in values:
                
                self.in_char_properties.append([self.job_id,
                                                object if type(object) is int else object.id,
                                                property.id,
                                                self.property_char_offset,
                                                char_block,
                                                val
                                                ])
                char_block += 1
            
            self.property_char_offset += 1

        elif property.get_type() == 'integer' and type(value) is int:
            
            self.in_int_properties.append([self.job_id,
                                           object if type(object) is int else object.id,
                                           property.id,
                                           self.property_int_offset,
                                           value
                                           ])

            self.property_int_offset += 1

    def save(self):
        """
        Really save.
        """
        
        self._empty_in_tables()
        
        logging.debug('executing cache_init %d ...', self.job_id)
        self.kb._execute_function(self.cursor, 'CACHE_INIT', '%s' % self.job_id)
        self.raw_connection.commit()
        logging.debug('executed')

        
        # add all the dependency to other projects
        for project in self.dependent_projects:
            link_id = self.add_link(1056, self.project_id, project)
            self.add_property(link_id, self.kb.dependencyKind, 0)
            
        
        # flush IN tables

        for val in self.in_links:
            val[0] = self.job_id
        ins = self.IN_LINKS.insert()
        self.cursor.executemany(str(ins.compile()), self.in_links)
        self.raw_connection.commit()
        self.in_links = []
        

        for val in self.in_objects:
            val[0] = self.job_id
        ins = self.IN_OBJECTS.insert()
        self.cursor.executemany(str(ins.compile()), self.in_objects)
        self.raw_connection.commit()
        self.in_objects = []

        for val in self.in_positions:
            val[0] = self.job_id
        ins = self.ins = self.IN_POSITIONS.insert()
        self.cursor.executemany(str(ins.compile()), self.in_positions)
        self.raw_connection.commit()
        self.in_positions = []

        for val in self.in_char_properties:
            val[0] = self.job_id
        ins = self.IN_CHAR_PROPERTIES.insert()
        self.cursor.executemany(str(ins.compile()), self.in_char_properties)
        self.raw_connection.commit()
        self.in_char_properties = []
        
        for val in self.in_int_properties:
            val[0] = self.job_id
        ins = self.IN_INT_PROPERTIES.insert()
        self.cursor.executemany(str(ins.compile()), self.in_int_properties)
        self.raw_connection.commit()
        self.in_int_properties = []
        
        logging.debug('executing cache_processid %d, %d ...', self.job_id, self.user_project_id)
        self.kb._execute_function(self.cursor, 'CACHE_PROCESSID', '%s,%s' % (self.job_id, self.user_project_id))
        self.raw_connection.commit()
        logging.debug('executed')
        logging.debug('executing cache_flushdata %d', self.job_id)
        self.kb._execute_function(self.cursor, 'CACHE_FLUSHDATA', '%s' % self.job_id)
        self.raw_connection.commit()
        logging.debug('executed')

    def _create_project(self, name):
        """
        Creates the result project for that saving session.
        """
        self.project_id = self._create_object(name, self.project_type)
        
        link_id = self.add_link(1054, self.project_id, self.project_id)
        self.add_property(link_id, self.kb.projectRelationKind, 0)

        self.add_property(self.project_id, self.kb.identification_name, name)
        self.add_property(self.project_id, self.kb.identification_fullname, name)
        
        try:
            id_property = self.kb.metamodel.get_property(id=140567)
            version_property = self.kb.metamodel.get_property(id=140568)
            
            self.add_property(self.project_id, id_property, self.plugin_id)
            self.add_property(self.project_id, version_property, self.plugin_version)
            
        except KeyError:
            # before 7.3.6
            pass
        
        
    def _create_object(self, guid, object_type):
        short_guid = guid[0:600]
        
        long_guid = guid
        if len(long_guid) > 1000:
            crc = binascii.crc32(long_guid)
            long_guid = '%s <#%08X>' % (long_guid[0:1000], crc)
        
        object_id = self.next_id
        self.next_id += 1
        
        self.in_objects.append([self.job_id,
                                object_id,
                                long_guid, # so called guid
                                short_guid, # guid but with max 600
                                object_type if type(object_type) is int else object_type.id
                                ])
        return object_id
    
    def _empty_in_tables(self):
        
        ins = self.IN_OBJECTS.delete().where(self.IN_OBJECTS.c.session_id == self.job_id)
        self.engine.execute(ins)
        
        ins = self.IN_LINKS.delete().where(self.IN_LINKS.c.session_id == self.job_id)
        self.engine.execute(ins)
        
        ins = self.IN_CHAR_PROPERTIES.delete().where(self.IN_CHAR_PROPERTIES.c.session_id == self.job_id)
        self.engine.execute(ins)

        ins = self.IN_INT_PROPERTIES.delete().where(self.IN_INT_PROPERTIES.c.session_id == self.job_id)
        self.engine.execute(ins)
    
    def _display_in_tables(self):
        
        logging.debug('IN_OBJECTS :')
        self.cursor.execute("select * from IN_OBJECTS")
        self._print_result()

        logging.debug('IN_LINKS :')
        self.cursor.execute("select * from IN_LINKS")
        self._print_result()

        logging.debug('IN_CHAR_PROPERTIES :')
        self.cursor.execute("select * from IN_CHAR_PROPERTIES")
        self._print_result()

        logging.debug('IN_INT_PROPERTIES :')
        self.cursor.execute("select * from IN_INT_PROPERTIES")
        self._print_result()

    def _print_result(self):
        for line in self.cursor:
            logging.debug('%s', str(line))
        
    def _add_dependency(self, o):
        """
        Add a dependency to the object's project
        """
        if type(o) is int:
            return
        
        for project in o.get_projects():
            self.dependent_projects.add(project)


