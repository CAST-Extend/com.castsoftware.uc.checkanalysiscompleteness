application = None

def get_current_application():
    global application
    return application

def set_current_application(current):
    global application
    application = current


def is_debug_log():
    """
    True when debug log is activated
    """
    # get intermediate folder (LISA)
    import logging
    import sys
    
    intermediate_folder = None
    
    # when launched by CMS : we have the option
    try:
        arguments = sys.argv
        intermediate_option = arguments.index('--intermediate')
        if intermediate_option > 0:
            intermediate_folder = arguments[intermediate_option+1]   
    
    except:
        # many things may have happen : for example we are running from anarun.
        pass
    
    # probably in test mode...
    if not intermediate_folder:
        return True
    
    try:
        import glob, os
        import xml.etree.ElementTree as ET
        
        have_settings = False
        
        # scan the JobSettings.xml files
        # each one is generated when doing an analysis (either full or partial)
        for settings in glob.glob(os.path.join(intermediate_folder, '*', 'JobSettings.xml')):
            
            have_settings = True
            
            tree = ET.parse(settings)
            root = tree.getroot()
        
            for node in root.iter('includeDebug'):
                
                if node.text.strip() == 'true':
                    return True
                if node.text.strip() == 'false':
                    return False
                
        if have_settings:
            # Case : take a snapshot
            # the job settings do not contain the option : so no debug
            return False  
    except:
        # be cool
        pass
    
    # probably in test mode...
    return True



report_path = None

def get_report_path():
    global report_path
    return report_path

def set_report_path(path):
    global report_path
    report_path = path

current_event = None

def get_current_event():
    global current_event
    return current_event

def set_current_event(event):
    global current_event
    current_event = event
